import { useState, useEffect, useCallback } from "react";
import { motion } from "framer-motion";
import { Bot, GitBranch, Heart, Sparkles, ExternalLink, LogOut, Save, Trash2, Users, StickyNote } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import ThemeToggle from "@/components/ThemeToggle";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";

const tools = [
  { icon: Bot, title: "Cursor", desc: "AI-first code editor for rapid development", cta: "Launch Cursor", href: "https://cursor.sh" },
  { icon: GitBranch, title: "Git Resources", desc: "Branching strategy, PR guidelines, version control standards", cta: "View Git Docs", href: "https://git-scm.com/doc" },
  { icon: Heart, title: "Lovable", desc: "No-code/low-code AI app builder", cta: "Open Lovable", href: "https://lovable.dev" },
  { icon: Sparkles, title: "v0", desc: "UI generation and rapid frontend creation tool", cta: "Open v0", href: "https://v0.dev" },
];

const NOTES_KEY = "cdu_notes";

const Dashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [notes, setNotes] = useState(() => localStorage.getItem(NOTES_KEY) || "");
  const [saved, setSaved] = useState(true);

  useEffect(() => {
    if (!user) { navigate("/"); return; }
  }, [user, navigate]);

  // Auto-save debounce
  useEffect(() => {
    const t = setTimeout(() => {
      localStorage.setItem(NOTES_KEY, notes);
      setSaved(true);
    }, 800);
    return () => clearTimeout(t);
  }, [notes]);

  const handleNotesChange = useCallback((val: string) => {
    setNotes(val);
    setSaved(false);
  }, []);

  const clearNotes = () => { setNotes(""); localStorage.removeItem(NOTES_KEY); setSaved(true); };
  const saveNotes = () => { localStorage.setItem(NOTES_KEY, notes); setSaved(true); };

  const handleLogout = () => { logout(); navigate("/"); };

  if (!user) return null;

  const fadeUp = (delay = 0) => ({
    initial: { opacity: 0, y: 16 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.4, delay },
  });

  return (
    <div className="min-h-screen" style={{ background: "var(--page-gradient)", backgroundAttachment: "fixed" }}>
      {/* Navbar */}
      <nav className="glass sticky top-0 z-50">
        <div className="container mx-auto px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">CD</span>
            </div>
            <span className="font-display font-bold text-foreground text-lg hidden sm:inline">
              Citizen<span className="text-primary">Dev</span>
            </span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-muted-foreground hidden sm:inline">
              Welcome, <span className="font-semibold text-foreground">{user.fullName}</span>
            </span>
            <ThemeToggle />
            <Button variant="outline" size="sm" onClick={handleLogout} className="glass gap-2">
              <LogOut className="h-4 w-4" /> Logout
            </Button>
          </div>
        </div>
      </nav>

      <div className="container mx-auto px-6 py-10 space-y-10">
        {/* Welcome Card */}
        <motion.div {...fadeUp()} className="glass rounded-2xl p-8">
          <h1 className="text-2xl font-display font-bold text-foreground mb-2">
            Hello, {user.fullName} 👋
          </h1>
          <p className="text-muted-foreground leading-relaxed max-w-2xl">
            Welcome to the Citizen Developer AI Enablement Portal. Access your team's tools, take notes, and stay productive.
          </p>
        </motion.div>

        {/* Tools Grid */}
        <motion.div {...fadeUp(0.1)}>
          <h2 className="text-lg font-display font-bold text-foreground mb-5 flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" /> Tools & Resources
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {tools.map((t, i) => (
              <motion.a
                key={t.title}
                href={t.href}
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.15 + i * 0.08 }}
                className="glass glass-hover group flex flex-col justify-between rounded-2xl p-6 no-underline transition-all duration-300 hover:-translate-y-1.5"
              >
                <div>
                  <div className="mb-4 inline-flex rounded-xl bg-primary/10 p-3 transition-colors duration-300 group-hover:bg-primary/20">
                    <t.icon className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-base font-semibold text-foreground mb-1">{t.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{t.desc}</p>
                </div>
                <div className="mt-4 flex items-center gap-2 text-sm font-medium text-primary opacity-70 group-hover:opacity-100 transition-opacity">
                  {t.cta} <ExternalLink className="h-3.5 w-3.5" />
                </div>
              </motion.a>
            ))}
          </div>
        </motion.div>

        {/* Notepad */}
        <motion.div {...fadeUp(0.2)} className="glass rounded-2xl p-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-display font-bold text-foreground flex items-center gap-2">
              <StickyNote className="h-5 w-5 text-primary" /> My AI Notes
            </h2>
            <div className="flex items-center gap-2">
              <span className="text-xs text-muted-foreground">{saved ? "Saved" : "Unsaved..."}</span>
              <Button variant="outline" size="sm" onClick={saveNotes} className="gap-1.5"><Save className="h-3.5 w-3.5" /> Save</Button>
              <Button variant="outline" size="sm" onClick={clearNotes} className="gap-1.5 text-destructive hover:text-destructive"><Trash2 className="h-3.5 w-3.5" /> Clear</Button>
            </div>
          </div>
          <Textarea
            placeholder="Write your notes here... They'll auto-save to your browser."
            className="min-h-[200px] bg-background/50 resize-y"
            value={notes}
            onChange={(e) => handleNotesChange(e.target.value)}
          />
        </motion.div>

        {/* Team Info */}
        <motion.div {...fadeUp(0.3)} className="glass rounded-2xl p-8">
          <h2 className="text-lg font-display font-bold text-foreground mb-4 flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" /> Citizen Developer Team
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-6 max-w-3xl">
            This team enables AI-powered development using tools like Cursor, Git, Lovable, and v0.
            We focus on rapid prototyping, governance, and productivity optimization.
          </p>
          <div className="grid sm:grid-cols-2 gap-4 max-w-lg">
            <div className="rounded-xl bg-primary/5 p-4 border border-primary/10">
              <p className="text-xs text-muted-foreground mb-1">Director</p>
              <p className="font-semibold text-foreground">Vishal Nandwani</p>
            </div>
            <div className="rounded-xl bg-primary/5 p-4 border border-primary/10">
              <p className="text-xs text-muted-foreground mb-1">Senior Manager</p>
              <p className="font-semibold text-foreground">Venu Gopal Singh</p>
            </div>
          </div>
        </motion.div>

        <p className="text-center text-xs text-muted-foreground pb-8">
          © 2026 Citizen Developer Unit · Internal Use Only
        </p>
      </div>
    </div>
  );
};

export default Dashboard;
