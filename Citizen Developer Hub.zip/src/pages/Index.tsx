import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import TeamOverview from "@/components/TeamOverview";
import MissionVision from "@/components/MissionVision";
import WhatWeDo from "@/components/WhatWeDo";
import LoginSection from "@/components/LoginSection";

const Index = () => (
  <div className="min-h-screen">
    <Navbar />
    <HeroSection />
    <TeamOverview />
    <MissionVision />
    <WhatWeDo />
    <LoginSection />
    <footer className="py-8 text-center text-xs text-muted-foreground border-t border-border/50">
      © 2026 Citizen Developer Unit · Internal Use Only
    </footer>
  </div>
);

export default Index;
