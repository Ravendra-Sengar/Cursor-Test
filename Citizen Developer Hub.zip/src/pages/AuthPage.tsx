import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Lock, UserPlus, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import ThemeToggle from "@/components/ThemeToggle";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";

const AuthPage = () => {
  const { login, signup } = useAuth();
  const navigate = useNavigate();

  const [tab, setTab] = useState("login");

  // Login state
  const [lUser, setLUser] = useState("");
  const [lPass, setLPass] = useState("");
  const [lErr, setLErr] = useState("");

  // Signup state
  const [sName, setSName] = useState("");
  const [sUser, setSUser] = useState("");
  const [sPass, setSPass] = useState("");
  const [sConfirm, setSConfirm] = useState("");
  const [sErr, setSErr] = useState("");

  const handleLogin = () => {
    if (!lUser.trim() || !lPass.trim()) { setLErr("Please fill in all fields."); return; }
    const err = login(lUser, lPass);
    if (err) { setLErr(err); return; }
    navigate("/dashboard");
  };

  const handleSignup = () => {
    if (!sName.trim() || !sUser.trim() || !sPass.trim() || !sConfirm.trim()) { setSErr("Please fill in all fields."); return; }
    if (sPass !== sConfirm) { setSErr("Passwords do not match."); return; }
    if (sPass.length < 4) { setSErr("Password must be at least 4 characters."); return; }
    const err = signup(sName, sUser, sPass);
    if (err) { setSErr(err); return; }
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "var(--page-gradient)", backgroundAttachment: "fixed" }}>
      {/* Floating theme toggle */}
      <div className="fixed top-4 right-4 z-50">
        <ThemeToggle />
      </div>

      {/* Decorative orbs */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-32 -left-32 w-96 h-96 rounded-full bg-primary/10 blur-3xl animate-pulse-soft" />
        <div className="absolute -bottom-32 -right-32 w-96 h-96 rounded-full bg-primary/5 blur-3xl animate-pulse-soft" style={{ animationDelay: "2s" }} />
      </div>

      <div className="flex-1 flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          {/* Branding */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2.5 mb-4">
              <div className="h-10 w-10 rounded-xl bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-base">CD</span>
              </div>
              <span className="font-display font-bold text-foreground text-2xl">
                Citizen<span className="text-primary">Dev</span>
              </span>
            </div>
            <p className="text-sm text-muted-foreground">Internal Citizen Developer Access Portal</p>
          </div>

          {/* Auth Card */}
          <div className="glass rounded-2xl p-8">
            <Tabs value={tab} onValueChange={(v) => { setTab(v); setLErr(""); setSErr(""); }}>
              <TabsList className="w-full grid grid-cols-2 mb-6">
                <TabsTrigger value="login" className="gap-2"><Lock className="h-4 w-4" /> Login</TabsTrigger>
                <TabsTrigger value="signup" className="gap-2"><UserPlus className="h-4 w-4" /> Sign Up</TabsTrigger>
              </TabsList>

              <AnimatePresence mode="wait">
                <TabsContent value="login" key="login" asChild forceMount={tab === "login" ? true : undefined}>
                  <motion.div
                    initial={{ opacity: 0, x: -12 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 12 }}
                    transition={{ duration: 0.25 }}
                    className="space-y-4"
                  >
                    <div className="space-y-1.5">
                      <Label htmlFor="l-user" className="text-xs font-medium">Username</Label>
                      <Input id="l-user" placeholder="Enter username" value={lUser} onChange={(e) => { setLUser(e.target.value); setLErr(""); }} className="bg-background/50" />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="l-pass" className="text-xs font-medium">Password</Label>
                      <Input id="l-pass" type="password" placeholder="Enter password" value={lPass} onChange={(e) => { setLPass(e.target.value); setLErr(""); }} onKeyDown={(e) => e.key === "Enter" && handleLogin()} className="bg-background/50" />
                    </div>
                    {lErr && (
                      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-2 text-destructive text-sm">
                        <AlertCircle className="h-4 w-4 shrink-0" /><span>{lErr}</span>
                      </motion.div>
                    )}
                    <Button className="w-full" onClick={handleLogin}>Sign In</Button>
                  </motion.div>
                </TabsContent>

                <TabsContent value="signup" key="signup" asChild forceMount={tab === "signup" ? true : undefined}>
                  <motion.div
                    initial={{ opacity: 0, x: 12 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -12 }}
                    transition={{ duration: 0.25 }}
                    className="space-y-4"
                  >
                    <div className="space-y-1.5">
                      <Label htmlFor="s-name" className="text-xs font-medium">Full Name</Label>
                      <Input id="s-name" placeholder="Your full name" value={sName} onChange={(e) => { setSName(e.target.value); setSErr(""); }} className="bg-background/50" />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="s-user" className="text-xs font-medium">Username</Label>
                      <Input id="s-user" placeholder="Choose a username" value={sUser} onChange={(e) => { setSUser(e.target.value); setSErr(""); }} className="bg-background/50" />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="s-pass" className="text-xs font-medium">Password</Label>
                      <Input id="s-pass" type="password" placeholder="Create password" value={sPass} onChange={(e) => { setSPass(e.target.value); setSErr(""); }} className="bg-background/50" />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="s-confirm" className="text-xs font-medium">Confirm Password</Label>
                      <Input id="s-confirm" type="password" placeholder="Confirm password" value={sConfirm} onChange={(e) => { setSConfirm(e.target.value); setSErr(""); }} onKeyDown={(e) => e.key === "Enter" && handleSignup()} className="bg-background/50" />
                    </div>
                    {sErr && (
                      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center gap-2 text-destructive text-sm">
                        <AlertCircle className="h-4 w-4 shrink-0" /><span>{sErr}</span>
                      </motion.div>
                    )}
                    <Button className="w-full" onClick={handleSignup}>Create Account</Button>
                  </motion.div>
                </TabsContent>
              </AnimatePresence>
            </Tabs>
            <p className="text-[11px] text-center text-muted-foreground mt-6">🔒 Internal Access Only</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AuthPage;
