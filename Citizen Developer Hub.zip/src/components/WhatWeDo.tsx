import { motion } from "framer-motion";
import { Bot, GitBranch, Zap, Gauge } from "lucide-react";

const cards = [
  { icon: Bot, title: "AI Tool Enablement", desc: "Help business teams leverage AI tools like Cursor and v0 for rapid application development." },
  { icon: GitBranch, title: "Git Governance", desc: "Establish version control best practices, branch strategies, and collaboration standards." },
  { icon: Zap, title: "Rapid Prototyping", desc: "Build proof-of-concepts and MVPs quickly using AI-assisted tools." },
  { icon: Gauge, title: "Developer Productivity", desc: "Optimize workflows using automation, AI coding assistants, and internal accelerators." },
];

const WhatWeDo = () => (
  <section id="tools" className="py-24">
    <div className="container mx-auto px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="text-center mb-14"
      >
        <span className="text-xs font-semibold uppercase tracking-widest text-primary mb-3 block">Capabilities</span>
        <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-4">What We Do</h2>
        <p className="text-muted-foreground max-w-xl mx-auto">Strategic capabilities driving enterprise-wide digital transformation</p>
      </motion.div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((c, i) => (
          <motion.div
            key={c.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.1 }}
            className="glass glass-hover rounded-2xl p-7 transition-all duration-300 hover:-translate-y-1.5 group"
          >
            <div className="mb-5 inline-flex rounded-xl bg-primary/10 p-3.5 transition-colors duration-300 group-hover:bg-primary/20">
              <c.icon className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-base font-semibold text-foreground mb-2">{c.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{c.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default WhatWeDo;
