import { motion } from "framer-motion";
import { Users, User, Building2 } from "lucide-react";

const people = [
  { icon: User, label: "Director", value: "Vishal Nandwani" },
  { icon: Users, label: "Senior Manager", value: "Venu Gopal Singh" },
  { icon: Building2, label: "Team", value: "Citizen Developer Unit" },
];

const TeamOverview = () => (
  <section id="about" className="py-24">
    <div className="container mx-auto px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="text-center mb-14"
      >
        <span className="text-xs font-semibold uppercase tracking-widest text-primary mb-3 block">About Us</span>
        <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground mb-4">Team Overview</h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          The Citizen Developer Unit enables enterprise teams to build, prototype, and ship faster using AI-powered tools like Cursor, Git, Lovable, and v0.
        </p>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-6 max-w-3xl mx-auto">
        {people.map((item, i) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.1 }}
            className="glass glass-hover rounded-2xl p-7 flex flex-col items-center text-center transition-all duration-300 hover:-translate-y-1"
          >
            <div className="rounded-xl bg-primary/10 p-3 mb-4">
              <item.icon className="h-6 w-6 text-primary" />
            </div>
            <span className="text-[11px] font-semibold uppercase tracking-widest text-muted-foreground mb-1">{item.label}</span>
            <span className="text-base font-semibold text-foreground">{item.value}</span>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default TeamOverview;
