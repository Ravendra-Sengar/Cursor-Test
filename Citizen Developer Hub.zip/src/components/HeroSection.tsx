import { motion } from "framer-motion";
import { Shield, ArrowDown } from "lucide-react";

const HeroSection = () => (
  <section id="home" className="relative overflow-hidden min-h-screen flex items-center justify-center">
    {/* Gradient background */}
    <div className="absolute inset-0 bg-gradient-to-br from-[hsl(221,83%,53%)] via-[hsl(233,70%,48%)] to-[hsl(245,58%,42%)]" />

    {/* Animated orbs */}
    <div className="absolute inset-0 overflow-hidden">
      <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] rounded-full bg-white/10 blur-3xl animate-float" />
      <div className="absolute bottom-1/4 right-1/4 w-[400px] h-[400px] rounded-full bg-white/5 blur-3xl animate-float" style={{ animationDelay: "2s" }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-white/5 blur-3xl animate-pulse-soft" />
    </div>

    {/* Grid pattern */}
    <div
      className="absolute inset-0 opacity-[0.04]"
      style={{
        backgroundImage: "linear-gradient(white 1px, transparent 1px), linear-gradient(90deg, white 1px, transparent 1px)",
        backgroundSize: "60px 60px",
      }}
    />

    <div className="container relative mx-auto px-6 text-center pt-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-1.5 text-sm text-white/80 backdrop-blur-sm mb-8">
          <Shield className="h-4 w-4" />
          Internal AI Enablement Portal
        </div>
      </motion.div>

      <motion.h1
        className="text-5xl md:text-7xl font-display font-bold tracking-tight text-white mb-6"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.15 }}
      >
        Citizen Developer
        <br />
        <span className="text-white/70">Team</span>
      </motion.h1>

      <motion.p
        className="text-lg md:text-xl text-white/60 max-w-lg mx-auto font-light leading-relaxed"
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.3 }}
      >
        Empowering teams with AI-powered development tools and enterprise-grade governance
      </motion.p>

      <motion.div
        className="mt-16"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 1 }}
      >
        <a href="#about" className="inline-flex items-center justify-center w-10 h-10 rounded-full border border-white/20 text-white/50 hover:text-white hover:border-white/40 transition-colors">
          <ArrowDown className="h-4 w-4 animate-bounce" />
        </a>
      </motion.div>
    </div>
  </section>
);

export default HeroSection;
