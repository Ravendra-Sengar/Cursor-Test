import { motion } from "framer-motion";
import { Target, Eye } from "lucide-react";

const MissionVision = () => (
  <section className="py-24 bg-gradient-to-br from-[hsl(221,83%,53%/0.06)] via-[hsl(245,58%,51%/0.04)] to-transparent">
    <div className="container mx-auto px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="text-center mb-14"
      >
        <span className="text-xs font-semibold uppercase tracking-widest text-primary mb-3 block">Purpose</span>
        <h2 className="text-3xl md:text-4xl font-display font-bold text-foreground">Mission & Vision</h2>
      </motion.div>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {[
          {
            icon: Target,
            label: "Our Mission",
            text: "To democratize AI-powered development capabilities across the organization.",
          },
          {
            icon: Eye,
            label: "Our Vision",
            text: "To build a scalable citizen development ecosystem powered by AI tools.",
          },
        ].map((item, i) => (
          <motion.div
            key={item.label}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: i * 0.15 }}
            className="glass glass-hover rounded-2xl p-9 transition-all duration-300 hover:-translate-y-1 text-center"
          >
            <div className="inline-flex rounded-xl bg-primary/10 p-3.5 mb-5">
              <item.icon className="h-7 w-7 text-primary" />
            </div>
            <h3 className="text-sm font-semibold uppercase tracking-widest text-primary mb-4">{item.label}</h3>
            <p className="text-lg font-medium text-foreground leading-relaxed italic">"{item.text}"</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default MissionVision;
