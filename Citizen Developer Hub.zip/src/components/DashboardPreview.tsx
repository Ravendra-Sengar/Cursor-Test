import { motion } from "framer-motion";
import { Bot, GitBranch, Heart, Sparkles, ExternalLink, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";

const tools = [
  { icon: Bot, title: "Cursor", desc: "AI-first code editor for rapid development", cta: "Launch Cursor", href: "https://cursor.sh" },
  { icon: GitBranch, title: "Git Resources", desc: "Branching strategy, PR guidelines, version control standards", cta: "View Git Docs", href: "https://git-scm.com/doc" },
  { icon: Heart, title: "Lovable", desc: "No-code/low-code AI app builder", cta: "Open Lovable", href: "https://lovable.dev" },
  { icon: Sparkles, title: "v0", desc: "UI generation and rapid frontend creation tool", cta: "Open v0", href: "https://v0.dev" },
];

const DashboardPreview = ({ onLogout }: { onLogout: () => void }) => (
  <div className="max-w-4xl mx-auto">
    <div className="flex items-center justify-between mb-2">
      <h2 className="text-2xl font-display font-bold text-foreground">AI Enablement Portal</h2>
      <Button variant="outline" size="sm" onClick={onLogout} className="glass">
        <LogOut className="h-4 w-4 mr-2" /> Logout
      </Button>
    </div>
    <p className="text-muted-foreground mb-10">
      Welcome back, <span className="font-semibold text-foreground">citizenadmin</span> 👋 — Access your team's tools below.
    </p>

    <div className="grid sm:grid-cols-2 gap-6">
      {tools.map((t, i) => (
        <motion.a
          key={t.title}
          href={t.href}
          target="_blank"
          rel="noopener noreferrer"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: i * 0.1 }}
          className="glass glass-hover group flex flex-col justify-between rounded-2xl p-7 no-underline transition-all duration-300 hover:-translate-y-1.5"
        >
          <div>
            <div className="mb-4 inline-flex rounded-xl bg-primary/10 p-3.5 transition-colors duration-300 group-hover:bg-primary/20">
              <t.icon className="h-7 w-7 text-primary" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-1.5">{t.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{t.desc}</p>
          </div>
          <div className="mt-5 flex items-center gap-2 text-sm font-medium text-primary opacity-70 group-hover:opacity-100 transition-opacity">
            {t.cta}
            <ExternalLink className="h-4 w-4" />
          </div>
        </motion.a>
      ))}
    </div>

    <p className="text-center text-xs text-muted-foreground mt-12">Internal use only — Citizen Developer Unit</p>
  </div>
);

export default DashboardPreview;
