import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Lock, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import DashboardPreview from "./DashboardPreview";

const LoginSection = () => {
  const [loggedIn, setLoggedIn] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleLogin = () => {
    if (!username.trim() || !password.trim()) {
      setError("Please enter both username and password.");
      return;
    }
    if (username !== "citizenadmin" || password !== "AI@123") {
      setError("Invalid credentials. Please try again.");
      return;
    }
    setError("");
    setLoggedIn(true);
  };

  return (
    <section id="login" className="py-24">
      <div className="container mx-auto px-6">
        <AnimatePresence mode="wait">
          {!loggedIn ? (
            <motion.div
              key="login"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="flex justify-center"
            >
              <div className="glass rounded-2xl p-10 w-full max-w-sm">
                <div className="flex flex-col items-center mb-8">
                  <div className="rounded-xl bg-primary/10 p-3.5 mb-4">
                    <Lock className="h-6 w-6 text-primary" />
                  </div>
                  <h2 className="text-xl font-display font-bold text-foreground">Team Login</h2>
                  <p className="text-xs text-muted-foreground mt-1">Access the internal portal</p>
                </div>
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="username" className="text-xs font-medium">Username</Label>
                    <Input id="username" placeholder="Enter username" value={username} onChange={(e) => { setUsername(e.target.value); setError(""); }} className="bg-background/50" />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="password" className="text-xs font-medium">Password</Label>
                    <Input id="password" type="password" placeholder="Enter password" value={password} onChange={(e) => { setPassword(e.target.value); setError(""); }} onKeyDown={(e) => e.key === "Enter" && handleLogin()} className="bg-background/50" />
                  </div>
                  {error && (
                    <motion.div
                      initial={{ opacity: 0, y: -4 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-2 text-destructive text-sm"
                    >
                      <AlertCircle className="h-4 w-4 shrink-0" />
                      <span>{error}</span>
                    </motion.div>
                  )}
                  <Button className="w-full" onClick={handleLogin}>Sign In</Button>
                  <p className="text-[11px] text-center text-muted-foreground">🔒 Internal Access Only</p>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
            >
              <DashboardPreview onLogout={() => { setLoggedIn(false); setUsername(""); setPassword(""); }} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};

export default LoginSection;
