import { createContext, useContext, useState, useCallback, type ReactNode } from "react";

interface User {
  fullName: string;
  username: string;
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => string | null;
  signup: (fullName: string, username: string, password: string) => string | null;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const DEFAULT_USERS: Record<string, { password: string; fullName: string }> = {
  citizenadmin: { password: "AI@123", fullName: "Citizen Admin" },
};

const STORAGE_KEY = "cdu_users";

function getStoredUsers(): Record<string, { password: string; fullName: string }> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? { ...DEFAULT_USERS, ...JSON.parse(raw) } : { ...DEFAULT_USERS };
  } catch {
    return { ...DEFAULT_USERS };
  }
}

function storeUser(username: string, data: { password: string; fullName: string }) {
  const users = getStoredUsers();
  users[username] = data;
  // Don't persist the default user
  const { citizenadmin: _, ...rest } = users;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(rest));
}

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  const login = useCallback((username: string, password: string): string | null => {
    const users = getStoredUsers();
    const found = users[username];
    if (!found || found.password !== password) return "Invalid username or password.";
    setUser({ username, fullName: found.fullName });
    return null;
  }, []);

  const signup = useCallback((fullName: string, username: string, password: string): string | null => {
    const users = getStoredUsers();
    if (users[username]) return "Username already exists.";
    storeUser(username, { password, fullName });
    setUser({ username, fullName });
    return null;
  }, []);

  const logout = useCallback(() => setUser(null), []);

  return (
    <AuthContext.Provider value={{ user, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};
